# Exécution — Partie A uniquement
Prérequis : JDK 17, Maven, SoapUI, curl, xmllint.
Depuis le dossier extrait :
```sh
cd emprunt-codefirst
mvn compile exec:java
```
Ouvrir http://localhost:8080/bib/EmpruntService?wsdl puis ?xsd=1. Dans SoapUI, créer un SOAP Project avec le WSDL et tester A-117 / 978-1-234-5678-9.
Dans un second terminal, depuis le dossier racine extrait :
```sh
curl -i -X POST http://localhost:8080/bib/EmpruntService -H 'Content-Type: text/xml; charset=utf-8' -H 'SOAPAction: ""' --data-binary @xml/01-emprunter.xml
```
Remplacer le nom du fichier par 02, 09, 04, 05, 06, 07 et 08 (noms complets dans xml/) pour les tests correspondants. Le fichier 09 est volontairement invalide. Le fichier 03 est une réponse SOAP 1.2 à vérifier avec `xmllint --noout xml/03-fault-sender-12.xml`, pas une requête à envoyer. Pour tester mustUnderstand=0, modifier 07 et utiliser un ISBN disponible ou redémarrer le serveur. Le code Java contient déjà la modification finale de l’étape 4. Pour reproduire exactement les étapes 1–3, retirer temporairement le if de rendreLivre, puis le rétablir à l’étape 4 et redémarrer. Les emprunts sont conservés en mémoire jusqu’au redémarrage. Aucun test serveur réel n’a été exécuté ici (Maven indisponible).
