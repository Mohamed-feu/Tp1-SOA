# TP1 — Partie A : Code-first

Réponses théoriques et résultats attendus (à confirmer par exécution).

## Étape 1
1. `@WebService` déclare le service ; `@WebFault` déclare la faute métier.
2. Le constructeur vide permet à JAXB de créer les objets lors de la désérialisation XML.

## Étape 2
1. URL : http://localhost:8080/bib/EmpruntService. Opérations : emprunterLivre (idAdherent, isbn → emprunt), rendreLivre (numeroEmprunt → penalite). Messages WSDL attendus : emprunterLivre / emprunterLivreResponse et rendreLivre / rendreLivreResponse.
2. document/literal, SOAP 1.1.
3. isbn et dateRetour : xs:string. La regex Java ne figure pas dans le XSD généré.
4. Non, les paramètres locaux ne sont pas qualifiés par défaut.
5. HTTP : transport (POST, en-têtes, statut) ; XML : syntaxe des données ; SOAP : enveloppe, Header, Body et Fault ; WSDL : contrat décrivant opérations, messages, binding et adresse.

## Étape 3
1. Le binding SOAP/HTTP utilise POST pour transporter le message XML dans le corps HTTP, même pour une lecture.
2. Non : le jeton inconnu est facultatif sans mustUnderstand=1.
3. Une Fault VersionMismatch est attendue car le binding est SOAP 1.1, pas 1.2 (un rejet HTTP est également possible selon le traitement).
4. Les cinq corrections : envelope → Envelope ; namespace bibliotheque → bib ; bib:numero → numeroEmprunt sans préfixe ; fermeture rendreLivre → bib:rendreLivre ; Header avant Body. Les erreurs de casse et de fermeture rendent le XML invalide ; le mauvais namespace de l’opération empêche son identification. Un paramètre inconnu peut être ignoré par JAXB sans validation XSD, et un Header tardif peut être ignoré selon le parseur. Dans la version finale, un numéro absent déclenche une Fault Client. À vérifier sur Metro.

## Étape 4
1. ISBN invalide : Client, « ISBN mal formé : 978-2-10 », HTTP 500 attendu. Livre indisponible : Server, « Livre indisponible », HTTP 500 attendu.
2. detail contient LivreIndisponible avec isbn et retourPrevu (2026-12-02). Sa structure est définie dans le XSD référencé par le WSDL, et la faute est déclarée dans portType et binding.
3. Server est attendu pour l’exception métier déclarée. Ce n’est pas une panne technique : Client pourrait être choisi si l’on considère la demande incompatible avec l’état du livre ; une faute métier structurée reste préférable.
4. Avec 1, Fault MustUnderstand car le serveur ne traite pas le jeton. Avec 0, il peut ignorer le jeton ; le résultat dépend ensuite de la disponibilité du livre.
5. SOAP 1.1 : faultcode, faultstring, detail ; SOAP 1.2 : Code/Value, Reason/Text avec xml:lang, Detail. Client/Server deviennent Sender/Receiver.
