package mr.supnum.bib;
public class LivreIndisponibleInfo {
 public String isbn, retourPrevu;
 public LivreIndisponibleInfo() {}
 public LivreIndisponibleInfo(String isbn,String retourPrevu) { this.isbn=isbn; this.retourPrevu=retourPrevu; }
}
