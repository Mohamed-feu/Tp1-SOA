# TP1 — Partie B : Contract-first
Nom et prénom : Mohamed Jemal Hadj Weiss
Matricule : 24107

Les réponses ci-dessous sont déduites du contrat et du code ; les résultats d'exécution restent à vérifier.

## Étape 5
1. L'opération est `emprunterLivre`, le message de fault est `LivreIndisponibleFault` et l'action SOAP est `http://supnum.mr/bib/emprunterLivre`.
2. Signature attendue : `EmpruntType emprunterLivre(String idAdherent, String isbn) throws LivreIndisponibleFault`.
3. `dateRetour` est de type `XMLGregorianCalendar` (xs:date), contre `String` dans la partie A.
4. La classe attendue est `LivreIndisponibleFault`, issue du message WSDL de fault. Vérifier le nom généré par wsimport.

## Étape 6
1. Le WSDL fourni est utilisé grâce à `wsdlLocation`. Il contient le motif ISBN et `xs:date` ; les adresses publiées peuvent être adaptées.
2. Oui, les paramètres doivent porter le préfixe `bib:` car le schéma impose `elementFormDefault="qualified"`. Il faut aussi utiliser la SOAPAction du contrat.
3. Sans validation, l'ISBN invalide peut être accepté car le code ne vérifie pas son format. Avec `@SchemaValidation`, il est rejeté par une Fault de validation SOAP 1.1, normalement Client (HTTP 500). Le texte exact est à vérifier.
4. Sans `wsdlLocation`, Metro peut générer le contrat depuis l'interface et les classes annotées ; le motif ISBN risque de disparaître. Le type date et les espaces de noms peuvent être conservés grâce aux annotations générées. Comparer les WSDL réellement publiés.

## Conclusion
1. En A, ISBN et dateRetour sont des chaînes ; en B, ISBN est restreint par un motif et dateRetour est xs:date. A expose aussi rendreLivre, contrairement au contrat B.
2. En code-first, renommer un champ exposé peut modifier le WSDL et casser les clients existants. En contract-first, le contrat fourni reste la référence.
3. Contract-first pour Paiement car plusieurs équipes et langages utilisent le service. Code-first pour un prototype interne de deux jours.
