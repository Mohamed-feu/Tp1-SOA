# TP1 SOA — Partie B
Mohamed Jemal Hadj Weiss — 24107

Prérequis : JDK 17, Maven. Arrêter le serveur A avant de lancer B.

```sh
cd emprunt-contractfirst
mvn generate-sources
mvn compile exec:java
```
Ouvrir http://localhost:8080/bib/EmpruntService?wsdl . Dans un second terminal, depuis le dossier contenant xml :

```sh
curl -i -X POST http://localhost:8080/bib/EmpruntService -H 'Content-Type: text/xml; charset=utf-8' -H 'SOAPAction: "http://supnum.mr/bib/emprunterLivre"' --data-binary @xml/01-emprunter.xml
```
Répéter avec 02 puis 03. Pour comparer la validation, commenter l'annotation SchemaValidation, redémarrer, tester 03, puis rétablir l'annotation. Pour la question 4, retirer temporairement wsdlLocation et comparer le WSDL après redémarrage, puis restaurer.
Si wsimport génère un nom d'exception différent, adapter l'implémentation à l'interface générée. Ne pas modifier target à la main.

Le projet est fourni avec la validation activée (état final de l'étape 6). Les tests Maven et SOAP restent à effectuer sur machine.
